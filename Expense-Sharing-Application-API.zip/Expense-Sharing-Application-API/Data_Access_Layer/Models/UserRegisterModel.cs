﻿namespace Data_Access_Layer.Models
{
    public class UserRegisterModel
    {
        public string? Email { get; set; }
        public string? Password { get; set; }
        public string? Role { get; set; }
    }
}
